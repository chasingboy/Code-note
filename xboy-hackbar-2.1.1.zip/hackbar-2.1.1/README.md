# xboy:hackbar version 1.0.0
It was changed from hackvar v2.1.3
you can use this hackbar in any browser just open the hackbar-panel.html

#xboy:hackbar version 1.5.0
add WAF                1.1.0
add Autoexec           1.5.0
add Auto b64eocde      2.0.0
add Auto complete      2.1.1 



# Contributors
* [xboy](1215829953@qq.com)