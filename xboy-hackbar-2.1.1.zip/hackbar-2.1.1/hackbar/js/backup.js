
function autoexec() {
    var url= urlfield.value;
    url = url.replace(new RegExp(/\n|\r/g), '');
    show_div.style.display = 'none';
    temp_div.style.display = '';
    temp_div.innerHTML = "";

    var arr = [];

    if (check_url(url)){
        return;
    }
    if (confirm("Auto to execute ???") == true){

        if(postdataCbx.checked){
            /* post request */
            if (check_data(postdatafield.value)){
                return;
            }
            for (i = 0,len = arr.length;i < len;i++){
                if(!(request_post(arr[i],'temp_id_'+i,'temp_name_'+i,'http://127.0.0.1/www/test.php'))){
                    return;
                }
            }
        }else{
            /* get request */    
            for(i = 0,len = arr.length;i < len;i++){
                request_get(url,arr[i],'temp_id_'+i,'temp_name_'+i);
            }
        }
        alert('finish !!!');
    }else{

        return 0;

        }

}

function request_post(auto_value,iframe_id,iframe_name,post_action){
    temp_post_data_form.innerHTML = "";
    if (create_input_from_data(auto_value,temp_post_data_form)){
        create_iframe(iframe_id,iframe_name)
        temp_post_data_form.target = iframe_name;
        temp_post_data_form.action = post_action;
        temp_post_data_form.submit();
        return 1;
    }else{
        return 0;
    }

}

function request_get(url,auto_value,iframe_id,iframe_name){
    create_iframe(iframe_id,iframe_name);
    url = url.replace('*',auto_value);
    var temp_show_iframe = document.getElementById(iframe_id);
    temp_show_iframe.src = url;

}

function create_iframe(iframe_id,iframe_name){
    var obj = document.createElement("iframe");
    obj.style = "width: 100%;height: 100px;border:0px;border-bottom: solid 1px #C0C0C0;";
    obj.name = iframe_name;
    obj.id = iframe_id;
    temp_div.appendChild(obj);
}
