waf_bypass = {
	calc_waf: function (txt,choice){
		var txt = txt;				
		var str = choice;
		switch (str){
			case '1': txt = txt.replace(/ /g, "/**/");
				txt= ("/*!" + txt + "*/");
					break;
			case '2': txt = txt.replace(/ /g, "+");
				txt= ("/*!50000" + txt + "*/");
					break;
			case '3': txt = txt.replace(/ /g, "+");
				txt= ("/*!12345" + txt + "*/");
					break;
			case '4': txt = txt.replace(/ /g, "+");
				txt= ("/*!13337" + txt + "*/");
					break;	
			case '5': var txt = txt.toLowerCase();
				String.prototype.insert = new Function('intPos','strIns','return this.substring(0,intPos) + strIns + this.substring(intPos,this.length);');  	
				var input2val = txt.toUpperCase();  
				txt = (txt.insert(2,input2val));
				txt = txt.replace(/ /g, "/*&a=*/");
					break;
		// SETS
		case '6': var txt = txt.toLowerCase();
				String.prototype.insert = new Function('intPos','strIns','return this.substring(0,intPos) + strIns + this.substring(intPos,this.length);');  	
				var input2val = txt.toUpperCase();  
				txt = (txt.insert(2,input2val));
				txt = txt.replace(/ /g, "/*&a=*/");
					break;
		}
		return txt;
	} 		
}