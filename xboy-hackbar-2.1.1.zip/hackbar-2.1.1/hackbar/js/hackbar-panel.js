var urlfield = document.getElementById("hackbar_urlfield");
var postdatafield = document.getElementById("hackbar_postdatafield");
//var refererfield = document.getElementById("hackbar_refererfield");
var text2replacefield = document.getElementById("hackbar_text2replace");
var replacementfield = document.getElementById("hackbar_replacement");

/* ---------- main processs --------- */


var executeBtn = document.getElementById('hackbar_run');

var postdataCbx = document.getElementById("hackbar_enablepostdata");

var postdatacontainer = document.getElementById('hackbar_postdatacontainer');


var mysqlbasicinfoBtn = document.getElementsByName("mysqlbasicinfo")[0];
var mysqlconvertutf8Btn = document.getElementsByName("mysqlconvertutf8")[0];
var mysqlconvertlatin1Btn = document.getElementsByName("mysqlconvertlatin1")[0];
var mysqltosqlcharBtn = document.getElementsByName("mysqltosqlchar")[0];
var mssqltosqlcharBtn = document.getElementsByName("mssqltosqlchar")[0];
var oracletosqlcharBtn = document.getElementsByName("oracletosqlchar")[0];
var unionselectBtn = document.getElementsByName("unionselect")[0];
var spacestocommentsBtn = document.getElementsByName("spacestocomments")[0];

var stringtocharcodeBtn = document.getElementsByName("stringtocharcode")[0];
var stringtohtmlcharcodeBtn = document.getElementsByName("stringtohtmlcharcode")[0];
var xssalertBtn = document.getElementsByName("xssalert")[0];

var b64encodeBtn = document.getElementsByName("base64encode")[0];
var b64decodeBtn = document.getElementsByName("base64decode")[0];
var urlencodeBtn = document.getElementsByName("urlencode")[0];
var urldecodeBtn = document.getElementsByName("urldecode")[0];

var md5hashBtn = document.getElementsByName("md5hash")[0];
var sha1hashBtn = document.getElementsByName("sha1hash")[0];
var sha256hashBtn = document.getElementsByName("sha256hash")[0];
var rot13Btn = document.getElementsByName("rot13")[0];

var addslashesBtn = document.getElementsByName("addslashes")[0];
var stripslashesBtn = document.getElementsByName("stripslashes")[0];
var stripspacesBtn = document.getElementsByName("stripspaces")[0];
var reverseBtn = document.getElementsByName("reverse")[0];

var replaceBtn = document.getElementsByName("replace")[0];


//var plusBtn = document.getElementsByName("plus")[0];
//var minusBtn = document.getElementsByName("minus")[0];

var currentFocusField = null;

/* ----- my code ----- */

var scanBtn = document.getElementById('hackbar_scan');

var autoexecBtn = document.getElementById('hackbar_autoexec');

var b64encodeCbx = document.getElementById("hackbar_enable_b64encode");

var hackrequest = document.getElementById("hack_show_iframe_id");

var show_div = document.getElementById("show_div");
var temp_div = document.getElementById("temp_div");

var hack_postdata = document.getElementById("hack_postdata");

var url_input = document.getElementById("url_input");
var post_data_form = document.getElementById("post_data_form")


// add WAF

var waf_one_Btn = document.getElementsByName("waf_one")[0];
var waf_two_Btn = document.getElementsByName("waf_two")[0];
var waf_three_Btn = document.getElementsByName("waf_three")[0];
var waf_four_Btn = document.getElementsByName("waf_four")[0];


//add PHP
var php_filter_Btn = document.getElementsByName("php_filter")[0];
var php_input_Btn = document.getElementsByName("php_input")[0];
var php_data_Btn = document.getElementsByName("php_data")[0];
var php_file_Btn = document.getElementsByName("php_file")[0];
var some_usage_Btn = document.getElementsByName("some_usage")[0];


var plugins_leavesongs_Btn = document.getElementsByName("plugins-leavesongs")[0];

scanBtn.addEventListener('click', scan_exec);

/* ----- end ----- */

executeBtn.addEventListener('click', execute);

postdataCbx.addEventListener('change', togglepostdata);

// close referer
// refererCbx.addEventListener('change', togglereferer);

urlfield.focus();
currentFocusField = urlfield;

anonClickMenuFunct = function (event) {
    onClickMenu(event);
};

mysqlbasicinfoBtn.addEventListener('click', anonClickMenuFunct, false);
mysqlconvertutf8Btn.addEventListener('click', anonClickMenuFunct, false);
mysqlconvertlatin1Btn.addEventListener('click', anonClickMenuFunct, false);
mysqltosqlcharBtn.addEventListener('click', anonClickMenuFunct, false);
mssqltosqlcharBtn.addEventListener('click', anonClickMenuFunct, false);
oracletosqlcharBtn.addEventListener('click', anonClickMenuFunct, false);
unionselectBtn.addEventListener('click', anonClickMenuFunct, false);
spacestocommentsBtn.addEventListener('click', anonClickMenuFunct, false);
stringtocharcodeBtn.addEventListener('click', anonClickMenuFunct, false);
stringtohtmlcharcodeBtn.addEventListener('click', anonClickMenuFunct, false);
xssalertBtn.addEventListener('click', anonClickMenuFunct, false);
b64encodeBtn.addEventListener('click', anonClickMenuFunct, false);
b64decodeBtn.addEventListener('click', anonClickMenuFunct, false);
urlencodeBtn.addEventListener('click', anonClickMenuFunct, false);
urldecodeBtn.addEventListener('click', anonClickMenuFunct, false);
md5hashBtn.addEventListener('click', anonClickMenuFunct, false);
sha1hashBtn.addEventListener('click', anonClickMenuFunct, false);
sha256hashBtn.addEventListener('click', anonClickMenuFunct, false);
rot13Btn.addEventListener('click', anonClickMenuFunct, false);
addslashesBtn.addEventListener('click', anonClickMenuFunct, false);
stripslashesBtn.addEventListener('click', anonClickMenuFunct, false);
stripspacesBtn.addEventListener('click', anonClickMenuFunct, false);
reverseBtn.addEventListener('click', anonClickMenuFunct, false);
replaceBtn.addEventListener('click', anonClickMenuFunct, false);

/* ----- my code -----*/

autoexecBtn.addEventListener("click", auto_exec, false);

//WAF
waf_one_Btn.addEventListener('click', anonClickMenuFunct, false);
waf_two_Btn.addEventListener('click', anonClickMenuFunct, false);
waf_three_Btn.addEventListener('click', anonClickMenuFunct, false);
waf_four_Btn.addEventListener('click', anonClickMenuFunct, false);

// PHP
php_filter_Btn.addEventListener('click', anonClickMenuFunct, false);
php_input_Btn.addEventListener('click', anonClickMenuFunct, false);
php_file_Btn.addEventListener('click', anonClickMenuFunct, false);
php_data_Btn.addEventListener('click', anonClickMenuFunct, false);
some_usage_Btn.addEventListener('click', anonClickMenuFunct, false);

//plugins
plugins_leavesongs_Btn.addEventListener('click', anonClickMenuFunct, false);


/* ----- end ----- */

/* + -
plusBtn.addEventListener('click', anonClickMenuFunct, false);
minusBtn.addEventListener('click', anonClickMenuFunct, false);
*/

anonFocusFunct = function (event) {
    onFieldFocus(event);
};
urlfield.addEventListener('focus', anonFocusFunct, false);
postdatafield.addEventListener('focus', anonFocusFunct, false);
//refererfield.addEventListener('focus', anonFocusFunct, false);
urlfield.addEventListener('click', onFieldClick, false);
postdatafield.addEventListener('click', onFieldClick, false);
//refererfield.addEventListener('click', onFieldClick, false);

function onFieldFocus(event) {
    currentFocusField = event.currentTarget;
}

function onFieldClick(event) {
    event.currentTarget.focus();
}

function onClickMenu(event) {
    var txt = "";
    var newString = "";
    switch (event.currentTarget.name) {
        case 'mysqlbasicinfo':
            newString = SQL.selectionMySQLBasicInfo();
            this.setSelectedText(newString);
            break;
        case 'mysqlconvertutf8':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = SQL.selectionMySQLConvertUsing('utf8', txt);
                this.setSelectedText(newString);
            }
            break;
        case 'mysqlconvertlatin1':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = SQL.selectionMySQLConvertUsing('latin1', txt);
                this.setSelectedText(newString);
            }
            break;
        case 'mysqltosqlchar':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = SQL.selectionToSQLChar('mysql', txt);
                this.setSelectedText(newString);
            }
            break;
        case 'mssqltosqlchar':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = SQL.selectionToSQLChar('mssql', txt);
                this.setSelectedText(newString);
            }
            break;
        case 'oracletosqlchar':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = SQL.selectionToSQLChar('oracle', txt);
                this.setSelectedText(newString);
            }
            break;
        case 'unionselect':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = SQL.selectionToUnionSelect(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'spacestocomments':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = SQL.selectionToInlineComments('oracle', txt);
                this.setSelectedText(newString);
            }
            break;
        case 'stringtocharcode':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = XSS.selectionToChar('stringFromCharCode', txt);
                this.setSelectedText(newString);
            }
            break;
        case 'stringtohtmlcharcode':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = XSS.selectionToChar('htmlChar', txt);
                this.setSelectedText(newString);
            }
            break;
        case 'xssalert':
            newString = 'alert(String.fromCharCode(88, 83, 83))';
            this.setSelectedText(newString);
            break;
        case 'base64encode':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = Encrypt.base64Encode(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'base64decode':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = Encrypt.base64Decode(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'urlencode':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = urlencode(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'urldecode':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = unescape(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'md5hash':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = Encrypt.md5(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'sha1hash':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = Encrypt.sha1(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'sha256hash':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = Encrypt.sha2(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'rot13':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = Encrypt.rot13(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'addslashes':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = MISC.addSlashes(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'stripslashes':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = MISC.stripSlashes(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'stripspaces':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = MISC.stripSpaces(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'reverse':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = MISC.reverseString(txt);
                this.setSelectedText(newString);
            }
            break;
        case 'replace':
            if (text2replacefield.value || ''){
                var text2replace = text2replacefield.value;
                var replacement = replacementfield.value;
                txt = this.currentFocusField.value;
                newString = txt.replace(new RegExp(text2replace, 'g'), replacement);
                this.currentFocusField.value = newString;
            }
            break;

        /* ----- my code ----- */

        case 'waf_one':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = waf_bypass.calc_waf(txt,'1');
                this.setSelectedText(newString);
            }
            break;
        case 'waf_two':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = waf_bypass.calc_waf(txt,'2');
                this.setSelectedText(newString);
            }
            break;
        case 'waf_three':         
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = waf_bypass.calc_waf(txt,'3');
                this.setSelectedText(newString);
            }
            break;
        case 'waf_four': 
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = waf_bypass.calc_waf(txt,'4');
                this.setSelectedText(newString);
            }
            break;

        case 'php_filter':
            newString = php_module.php_protocol('php_filter');
            this.setSelectedText(newString);
            break;

        case 'php_file':
            newString = php_module.php_protocol('php_file');
            this.setSelectedText(newString);
            break;

        case 'php_input':
            newString = php_module.php_protocol('php_input');
            this.setSelectedText(newString);
            break;

        case 'php_data':
            newString = php_module.php_protocol('php_data');
            this.setSelectedText(newString);
            break;

        case 'some_usage':
            usage_path = php_module.php_protocol('some_usage');
            window.open(usage_path);
            break;

        case 'plugins-leavesongs':
            window.open('../plugins/leavesongs-tools/index.html');
        /* ----- end ----- */
        
        /* + -
        case 'plus':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = String(parseInt(txt)+1);
                this.setSelectedText(newString);
                execute();
            }
            break;
        case 'minus':
            txt = this.getSelectedText();
            if (txt !== false) {
                newString = String(parseInt(txt)-1);
                this.setSelectedText(newString);
                execute();
            }
            break;*/
    }
    currentFocusField.focus();
}

/* ---------- Actions --------- */

function getSelectedText() {
    var selectionStart = this.currentFocusField.selectionStart;
    var selectionEnd = this.currentFocusField.selectionEnd;
    if (selectionEnd - selectionStart < 1) {
        /* ----- my code -----*/
        alert("Select text before using this function!");
        /*
        browser.devtools.inspectedWindow.eval("alert(\"Select text before using this function!\");")
            .then(function (result, isException) {
                // no action
            });*/
        return false;
    }
    return this.currentFocusField.value.substr(selectionStart, selectionEnd - selectionStart);
}

function setSelectedText(str) {
    var selectionStart = this.currentFocusField.selectionStart;
    var selectionEnd = this.currentFocusField.selectionEnd;
    var pre = this.currentFocusField.value.substr(0, selectionStart);
    var post = this.currentFocusField.value.substr(selectionEnd, this.currentFocusField.value.length);
    this.currentFocusField.value = pre + str + post;
    this.currentFocusField.selectionStart = selectionStart;
    this.currentFocusField.selectionEnd = selectionStart + str.length;
}


function urlencode(inputstr) {
    var newString = escape(inputstr);
    newString = newString.replace(/\*/g, '%2a');
    newString = newString.replace(/\//g, '%2f');
    newString = newString.replace(/\+/g, '%2b');
    return newString;
}

function htmlEscape(inputstr) {
    return inputstr
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function htmlUnescape(inputstr){
    return inputstr
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&amp;/g, '&');
}

function loadUrl() {
    browser.devtools.inspectedWindow.eval("window.location.href")
        .then(function (result, isException) {
                if (isException)
                    urlfield.value = "";
                else
                    result = result.slice(0,-1);
                    urlfield.value = result;
            }
        );
}

/*
function splitUrl() {
    var uri = currentFocusField.value;
    uri = uri.replace(new RegExp(/&/g), "\n&");
    uri = uri.replace(new RegExp(/\?/g), "\n?");
    currentFocusField.value = uri;
    return true;
}
*/

var typePostdata = "";

function getPostData(dataString) {
    var dataString = dataString;
    if (dataString || '') {
        if (dataString.indexOf("Content-Disposition: form-data; name=") > -1) {
            typePostdata = "multipart";
            return dataString;
        }
        if (dataString.indexOf("&") > -1) {
            typePostdata = "formdata";
            dataString = dataString.replace(new RegExp(/\n|\r/g), '');
            dataString = dataString.replace(new RegExp(/\+/g), "%2B");
            return dataString.split('&');
        }
        if (dataString.indexOf("=") > -1) {
            typePostdata = "formdata";
            dataString = dataString.replace(new RegExp(/\n|\r/g), '');
            dataString = dataString.replace(new RegExp(/\+/g), "%2B");
            return [dataString];
        }
    }
    typePostdata = "raw";
    return dataString;
}

function execute() {
    var url = urlfield.value;
    url = url.replace(new RegExp(/\n|\r/g), '');
    temp_div.style.display = 'none';

    /* ----- my code ----- */
    if (url.length == 0){
        alert('please input url');
        return;
    }
    post_data_form.innerHTML = "";
    if(postdataCbx.checked){
       
        var postData = getPostData(postdatafield.value);
        if (typePostdata === "formdata") {
            
            for (var i = 0; i < postData.length; i++) {
                var field = postData[i].substr(0, postData[i].indexOf('='));
                var fieldvalue = postData[i].substr(postData[i].indexOf('=') + 1);
                if(b64encodeCbx.checked){
                    fieldvalue = auto_b64encode(field,fieldvalue)
                }
                create_input(field,fieldvalue);     
            }

            post_data_form.action = url;
            post_data_form.submit();

        }else{
            alert('post data type error!');
            return;
        }

    }else{
        if (b64encodeCbx.checked){
            url = argv_b64encode(url);
        }
        hack_show_iframe_id.src = url;
    }  
    /* ----- end ----- */
}

function togglepostdata() {
    if (postdataCbx.checked) {
        postdatacontainer.style.visibility = "visible";
        postdatacontainer.style.position = "relative";
    } else {
        postdatacontainer.style.visibility = "hidden";
        postdatacontainer.style.position = "absolute";
        
    }
}


/* close referer
function togglereferer() {
    if (refererCbx.checked) {
        referercontainer.style.visibility = "visible";
        referercontainer.style.position = "relative";
    } else {
        referercontainer.style.visibility = "hidden";
        referercontainer.style.position = "absolute";
    }
}
*/

/*----- my code -----*/

var method = '';
function auto_exec() {
    var url= urlfield.value;
    url = url.replace(new RegExp(/\n|\r/g), '');
    
    alert('此功能正在建设中...');
    return;
    /*
    var server_url = 'http://localhost:8888';

    if (check_url(url)){
        return;
    }

    if (confirm("Auto to execute ???") == true){
        post_data_form.innerHTML = "";
        
        postData = deal_postdata(url)
        if (postData == 0){
            return;
        }
        
        submit_form(url,postData,method,server_url);

        alert('finish !!!');

    }else{

        return 0;

        }*/

}


function deal_postdata(url){
    if(postdataCbx.checked){
            /* post request */

            if (check_data(postdatafield.value)){
                return;
            }
            method = 'post';
            var postData = postdatafield.value;

        }else{
            /* get request */
            method = 'get';
            var postData = url.split('?')[1];
        }

        var  tmp = getPostData(postData);
        if (typePostdata !== "formdata") {
            alert('post data type error!');
            return 0;
        }

        return postData;

}

function submit_form(url,postData,method,server_url){
    create_input('data',postData);
    create_input('url',url);
    create_input('method',method);

    post_data_form.action = server_url;
    post_data_form.submit();
}

function set_width(){
    var win_width = document.body.scrollWidth;
    url_input.style.width = (win_width - 150).toString() + "px";
    hack_postdata.style.width = (win_width - 150).toString() + "px";
}

window.onresize = function(){
    set_width()
    
}


function init_set(){
    set_width();
    postdatacontainer.style.position = "absolute";
    temp_div.style.display = 'none';
}

init_set()

function create_input(name,value){
    var obj = document.createElement("input");
    obj.name = name;
    obj.value = value;
    obj.type = 'hidden';
    post_data_form.appendChild(obj);

}



function auto_b64encode(field,value){
    b64encode_field = text2replacefield.value;
    if(field == b64encode_field){
        result = Encrypt.base64Encode(value);
        return result;
    }else{
        return value;
    }
    
}


function argv_b64encode(url){
    b64encode_field = text2replacefield.value;
    base_url = url.split('?')[0];
    param_url = url.split('?')[1];

    param_array = param_url.split('&');
    var tmp_url = '';
    for (var i = 0; i < param_array.length; i++){
        key = param_array[i].split('=')[0]
        value = param_array[i].split('=')[1]
        if(key == b64encode_field){
            value = Encrypt.base64Encode(value);
            param_array[i] = key + '=' + value
        }
    }
    url = base_url + '?' + param_array.join('&');
    return url;

}

suggestions = document.getElementById("suggestions");

var pid = 0;
function auto_complete(value=''){

    if(value.length == 0){
        return 0;
    }

    value = '=' + value;
    tmp_array = value.split('=');
    keyword = tmp_array[tmp_array.length - 1];
    res = search_keyword(keyword);

    if(res.length == 0){
        keyword = value.substr(value.length-4,4);
        res = search_keyword(keyword);
    }

    if(res.length == 0){
        keyword = value.substr(value.length-3,3);
        res = search_keyword(keyword);
    }

    if(res.length == 0){
        keyword = value.substr(value.length-2,2);
        res = search_keyword(keyword);
    }

    if(res.length == 0){
        keyword = value.substr(value.length-1,1);
        res = search_keyword(keyword);
    }

    if(res.length == 0){
        return;
    }else{
        clearTimeout(pid);
    }

    s = '<ul id="search_result"><li>' + res.join('</li><li>') + '</li></ul>';
    $('#suggestionshow').html(s);
    if(postdataCbx.checked){
        suggestions.style.top = "250px";
    }else{
        suggestions.style.top = "115px";
    }
    $('#suggestions').show();
    pid = setTimeout("$('#suggestions').hide()",3000);


    $('#search_result').click(function(e){
        txt = e.target.innerHTML;
        txt = txt.replace(keyword,'');
        setSelectedText(txt);
        $('#suggestions').hide();
    });

}

function get_cursort_position(obj) {
        var cursorIndex = 0;
        if (document.selection) {
            obj.focus();
            var range = document.selection.createRange();
            range.moveStart('character', -obj.value.length);
            cursorIndex = range.text.length;
        } else if (obj.selectionStart || obj.selectionStart==0){
            cursorIndex = obj.selectionStart;
        }
        return cursorIndex;
}

function scan_exec(){
    var url= urlfield.value;
    url = url.replace(new RegExp(/\n|\r/g), '');
    alert('此功能正在建设中...');
    return;

    
}
/* ----- end ----- */